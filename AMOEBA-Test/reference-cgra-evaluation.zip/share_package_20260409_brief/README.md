# CGRA Innovus Share Package (Brief)

This is a brief share package for result review.
The original files were copied into this folder without modifying their contents.

## Included Content

- `scripts/`
  - Run scripts and helper Tcl files

- `inputs/`
  - `cgra_netlist.v`
  - `cgra.sdc`

- `results/cgra_DETAILS.rpt`
  - Compact summary of area / power / wirelength / WS / TNS by stage

- `results/power_post*.rpt`
  - Power breakdown reports for each major stage

- `results/summaryReport/post_route.sum`
  - Area breakdown and design summary

- `results/timingReports/`
  - Detailed timing breakdown reports

- `results/tile_grid_regions.rpt`
  - 4x4 tile-grid region information

- `results/layout.gif`
  - Exported layout image

## Not Included

- Innovus `log/`
- Full `enc/` database
- DEF snapshots
- Intermediate implementation databases

If more detail is needed later, send the full package instead of this brief one.

