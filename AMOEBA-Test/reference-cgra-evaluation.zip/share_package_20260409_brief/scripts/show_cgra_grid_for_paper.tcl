# Draw a paper-friendly 4x4 CGRA grid overlay on top of the routed layout.
#
# Differences from show_cgra_grid_only.tcl:
# - does NOT use rulers, so no coordinate numbers appear
# - keeps routed layout visible
# - draws only white tile boundaries and optional tile labels
#
# Usage inside Innovus:
#   cd /workspace/code/phdyear0/jiajunswork/cgra
#   set restore_db_file_check 0
#   restoreDesign enc/cgra.enc.dat Cgra4x4TemplateRTL
#   source show_cgra_grid_for_paper.tcl
#
# Optional controls before source:
#   set ::qjj_tile_outline_width 10
#   set ::qjj_tile_label_enable 0
#   set ::qjj_tile_label_mode tile

proc qjj_require_design_loaded {} {
    if {[catch {set top_name [dbGet top.name]}] || $top_name eq "" || $top_name eq "0x0"} {
        error "No Innovus design is loaded. Run restoreDesign first."
    }
}

proc qjj_load_grid_boxes_for_paper {{rpt_file "tile_grid_regions.rpt"}} {
    if {![file exists $rpt_file]} {
        error "Did not find $rpt_file in the current Innovus working directory."
    }

    set boxes [dict create]
    set fp [open $rpt_file r]
    set is_header 1
    while {[gets $fp line] >= 0} {
        if {$is_header} {
            set is_header 0
            continue
        }
        if {[string trim $line] eq ""} {
            continue
        }

        set fields [split $line ,]
        if {[llength $fields] != 8} {
            continue
        }

        lassign $fields tile_id group_name mode inst_count llx lly urx ury
        dict set boxes $tile_id [list $llx $lly $urx $ury]
    }
    close $fp

    if {[dict size $boxes] < 16} {
        error "Only found [dict size $boxes] tile boxes in $rpt_file, expected 16."
    }
    return $boxes
}

proc qjj_clear_paper_grid_overlay {} {
    catch {clearAllRulers}
    catch {delete_gui_object -text}
    catch {delete_gui_object -shape}
}

proc qjj_paper_try_set_layer {layer_name color width} {
    catch {setLayerPreference $layer_name -isVisible 1}
    catch {setLayerPreference $layer_name -color $color}
    catch {setLayerPreference $layer_name -lineWidth $width}
}

proc qjj_prepare_paper_overlay_preferences {line_width} {
    qjj_paper_try_set_layer customLayers white $line_width
    qjj_paper_try_set_layer qjj_paper_grid white $line_width
    qjj_paper_try_set_layer qjj_paper_text white $line_width
    catch {setLayerPreference ruler -isVisible 0}

    catch {setPreference ShowInstanceText 0}
    catch {setPreference ShowNetText 0}
    catch {setPreference ShowIoPinText 0}
    catch {setPreference ShowGroupText 0}
    catch {setPreference ShowModuleText 0}
    catch {setPreference ShowInstancePinText 0}
    catch {setPreference ShowUtilizationText 0}
    catch {setPreference DisplayPinName 0}
}

proc qjj_draw_paper_grid_box {llx lly urx ury} {
    add_gui_shape -layer qjj_paper_grid -width $::qjj_tile_outline_width -line [list $llx $lly $urx $lly]
    add_gui_shape -layer qjj_paper_grid -width $::qjj_tile_outline_width -line [list $urx $lly $urx $ury]
    add_gui_shape -layer qjj_paper_grid -width $::qjj_tile_outline_width -line [list $urx $ury $llx $ury]
    add_gui_shape -layer qjj_paper_grid -width $::qjj_tile_outline_width -line [list $llx $ury $llx $lly]
}

proc qjj_add_paper_grid_label {tile_id llx lly urx ury} {
    if {![info exists ::qjj_tile_label_enable]} {
        set ::qjj_tile_label_enable 0
    }
    if {!$::qjj_tile_label_enable} {
        return
    }

    if {![info exists ::qjj_tile_label_mode]} {
        set ::qjj_tile_label_mode "id"
    }

    set cx [expr {($llx + $urx) / 2.0}]
    set cy [expr {($lly + $ury) / 2.0}]

    switch -- [string tolower $::qjj_tile_label_mode] {
        tile {
            set label_text [format "tile_%d" $tile_id]
        }
        default {
            set label_text $tile_id
        }
    }

    add_gui_text -layer qjj_paper_text -label $label_text -fixed_height 18 -pt [list $cx $cy]
}

proc qjj_draw_4x4_paper_grid {{rpt_file "tile_grid_regions.rpt"}} {
    qjj_require_design_loaded

    if {![info exists ::qjj_tile_outline_width]} {
        set ::qjj_tile_outline_width 7
    }
    if {![info exists ::qjj_tile_label_enable]} {
        set ::qjj_tile_label_enable 0
    }

    if {$::qjj_tile_outline_width < 1} {
        set ::qjj_tile_outline_width 1
    }
    if {$::qjj_tile_outline_width > 7} {
        puts "Requested tile outline width $::qjj_tile_outline_width is too large for add_gui_shape; clamping to 7."
        set ::qjj_tile_outline_width 7
    }

    set boxes [qjj_load_grid_boxes_for_paper $rpt_file]
    qjj_clear_paper_grid_overlay
    qjj_prepare_paper_overlay_preferences $::qjj_tile_outline_width

    for {set tile_id 0} {$tile_id < 16} {incr tile_id} {
        if {![dict exists $boxes $tile_id]} {
            continue
        }
        lassign [dict get $boxes $tile_id] llx lly urx ury
        qjj_draw_paper_grid_box $llx $lly $urx $ury
        qjj_add_paper_grid_label $tile_id $llx $lly $urx $ury
    }

    puts ""
    puts "Paper-friendly 4x4 CGRA grid overlay is ready."
    puts "The grid uses GUI shapes, so ruler coordinate numbers are suppressed."
    puts "If labels are cluttered, keep ::qjj_tile_label_enable at 0."

    catch {fit}
    catch {redraw}
}

qjj_draw_4x4_paper_grid
