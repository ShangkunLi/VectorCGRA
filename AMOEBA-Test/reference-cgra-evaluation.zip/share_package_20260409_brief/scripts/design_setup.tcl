# Custom design setup for cgra Innovus handoff.

set DESIGN cgra
set TOP_MODULE Cgra4x4TemplateRTL

set HANDOFF_DIR "./syn_handoff"
set NETLIST "${HANDOFF_DIR}/${DESIGN}.v"
set SDC_FILE "${HANDOFF_DIR}/${DESIGN}.sdc"

set SITE "asap7sc7p5t"
set TOP_ROUTING_LAYER 9
set HALO_WIDTH 0

# The current post-route density is still only ~36.7%, while the worst setup
# paths are long diagonal tile-to-tile paths that cross shared memory/control
# logic. Tighten the core one notch so those global paths shorten before we
# give up and relax frequency or add RTL pipelining.
set FP_UTIL 0.38
set FP_MARGIN 3
set PIN_SPREAD_FRACTION 0.98

# 4x4 logical tile floorplan constraints.
# This configuration intentionally biases toward visible physical separation.
# If placement/timing becomes too hard to converge, relax in this order:
#   1. reduce TILE_GRID_BOUNDARY_PLACE_BLKG_WIDTH
#   2. reduce TILE_GRID_CHANNEL
#   3. switch TILE_GRID_MODE back to "region"
set TILE_GRID_ENABLE 1
set TILE_GRID_ROWS 4
set TILE_GRID_COLS 4
set TILE_GRID_MODE "fence"
set TILE_GRID_CHANNEL 6.0

# Add a soft placement blockage ring inside each tile box so placement does
# not smear standard cells across tile boundaries.
set TILE_GRID_BOUNDARY_PLACE_BLKG 1
set TILE_GRID_BOUNDARY_PLACE_BLKG_WIDTH 4.0

# Optional routing blockage ring on tile edges. Keep this off by default; it
# makes boundaries even cleaner but can hurt routability on cross-tile nets.
set TILE_GRID_BOUNDARY_ROUTE_BLKG 0
set TILE_GRID_BOUNDARY_ROUTE_BLKG_WIDTH 2.0
set TILE_GRID_BOUNDARY_ROUTE_LAYERS {M2 M3 M4}

set REF_ROOT "/workspace/code/phdyear0/reference/MacroPlacement"
set UTIL_ROOT "${REF_ROOT}/Flows/util"
set PDN_CONFIG "${REF_ROOT}/Enablements/ASAP7/util/pdn_config.tcl"
