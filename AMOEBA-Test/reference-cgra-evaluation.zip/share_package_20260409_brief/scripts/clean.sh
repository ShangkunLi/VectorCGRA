#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${ROOT_DIR}"

remove_path() {
    local path="$1"
    if [ -e "$path" ]; then
        rm -rf -- "$path"
        printf 'removed %s\n' "$path"
    fi
}

# Generated directories from the Innovus flow.
for path in \
    def \
    enc \
    log \
    mp_data \
    summaryReport \
    syn_handoff \
    timingReports
do
    remove_path "$path"
done

# Top-level generated reports, logs, command traces, and DEF snapshots.
for path in \
    cgra.def \
    cgra_route.def \
    cgra_DETAILS.rpt \
    power.rpt \
    power_postCTS.rpt \
    power_postRoute.rpt \
    power_postRouteOpt.rpt \
    power_postSynth.rpt \
    power_preCTS.rpt \
    rc_model.bin \
    scheduling_file.cts.726 \
    tile_grid_regions.rpt \
    Cgra4x4TemplateRTL.conn.rpt \
    Cgra4x4TemplateRTL.conn.rpt.old \
    Cgra4x4TemplateRTL.geom.rpt \
    Cgra4x4TemplateRTL.geom.rpt.old
do
    remove_path "$path"
done

# Rotated Innovus logs and command transcripts.
for path in innovus.log innovus.log? innovus.logv innovus.logv? innovus.cmd innovus.cmd?; do
    remove_path "$path"
done

printf 'clean complete\n'
