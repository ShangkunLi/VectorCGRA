# Draw only the logical 4x4 CGRA tile borders on top of an Innovus design.
# This version uses rulers because they are usually visible above routed layout.
#
# Usage inside Innovus:
#   cd /workspace/code/phdyear0/jiajunswork/cgra
#   set restore_db_file_check 0
#   restoreDesign enc/cgra.enc.dat Cgra4x4TemplateRTL
#   source show_cgra_grid_only.tcl
#
# Optional controls before source:
#   set ::qjj_tile_outline_width 7
#   set ::qjj_tile_label_enable 0
#   set ::qjj_tile_label_mode tile

proc qjj_require_design_loaded {} {
    if {[catch {set top_name [dbGet top.name]}] || $top_name eq "" || $top_name eq "0x0"} {
        error "No Innovus design is loaded. Run restoreDesign first."
    }
}

proc qjj_load_grid_boxes {{rpt_file "tile_grid_regions.rpt"}} {
    if {![file exists $rpt_file]} {
        error "Did not find $rpt_file in the current Innovus working directory."
    }

    set boxes [dict create]
    set fp [open $rpt_file r]
    set is_header 1
    while {[gets $fp line] >= 0} {
        if {$is_header} {
            set is_header 0
            continue
        }
        if {[string trim $line] eq ""} {
            continue
        }

        set fields [split $line ,]
        if {[llength $fields] != 8} {
            continue
        }

        lassign $fields tile_id group_name mode inst_count llx lly urx ury
        dict set boxes $tile_id [list $llx $lly $urx $ury]
    }
    close $fp

    if {[dict size $boxes] < 16} {
        error "Only found [dict size $boxes] tile boxes in $rpt_file, expected 16."
    }
    return $boxes
}

proc qjj_clear_grid_overlay {} {
    catch {clearAllRulers}
    catch {delete_gui_object -text}
}

proc qjj_prepare_overlay_preferences {line_width} {
    catch {setLayerPreference ruler -isVisible 1}
    catch {setLayerPreference ruler -color white}
    catch {setLayerPreference ruler -lineWidth $line_width}
    catch {setLayerPreference customLayers -isVisible 1}
    catch {setLayerPreference customLayers -color white}
    catch {setLayerPreference customLayers -lineWidth $line_width}

    catch {setPreference ShowRoute 1}
    catch {setPreference ShowInstanceText 0}
    catch {setPreference ShowNetText 0}
    catch {setPreference ShowIoPinText 0}
}

proc qjj_add_grid_ruler {x1 y1 x2 y2} {
    createRuler -coordinates [list $x1 $y1 $x2 $y2]
}

proc qjj_add_tile_box {llx lly urx ury} {
    qjj_add_grid_ruler $llx $lly $urx $lly
    qjj_add_grid_ruler $urx $lly $urx $ury
    qjj_add_grid_ruler $urx $ury $llx $ury
    qjj_add_grid_ruler $llx $ury $llx $lly
}

proc qjj_add_tile_label {tile_id llx lly urx ury} {
    if {![info exists ::qjj_tile_label_enable]} {
        set ::qjj_tile_label_enable 0
    }
    if {!$::qjj_tile_label_enable} {
        return
    }

    if {![info exists ::qjj_tile_label_mode]} {
        set ::qjj_tile_label_mode "id"
    }

    set cx [expr {($llx + $urx) / 2.0}]
    set cy [expr {($lly + $ury) / 2.0}]

    switch -- [string tolower $::qjj_tile_label_mode] {
        tile {
            set label_text [format "tile_%d" $tile_id]
        }
        default {
            set label_text $tile_id
        }
    }

    add_gui_text -layer qjj_grid_text -label $label_text -fixed_height 18 -pt [list $cx $cy]
}

proc qjj_draw_4x4_grid {{rpt_file "tile_grid_regions.rpt"}} {
    qjj_require_design_loaded

    if {![info exists ::qjj_tile_outline_width]} {
        set ::qjj_tile_outline_width 7
    }

    set boxes [qjj_load_grid_boxes $rpt_file]
    qjj_clear_grid_overlay
    qjj_prepare_overlay_preferences $::qjj_tile_outline_width

    for {set tile_id 0} {$tile_id < 16} {incr tile_id} {
        if {![dict exists $boxes $tile_id]} {
            continue
        }
        lassign [dict get $boxes $tile_id] llx lly urx ury
        qjj_add_tile_box $llx $lly $urx $ury
        qjj_add_tile_label $tile_id $llx $lly $urx $ury
    }

    puts ""
    puts "Logical 4x4 tile numbering:"
    puts "12 13 14 15"
    puts " 8  9 10 11"
    puts " 4  5  6  7"
    puts " 0  1  2  3"
    puts ""
    puts "4x4 CGRA grid overlay is ready."
    puts "This version draws each tile box with rulers so it stays visible over routed layout."
    puts "If labels are cluttered, keep ::qjj_tile_label_enable at 0."

    catch {fit}
}

qjj_draw_4x4_grid
