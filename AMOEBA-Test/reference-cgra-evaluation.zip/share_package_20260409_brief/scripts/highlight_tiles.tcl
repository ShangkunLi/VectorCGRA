# Highlight logical 4x4 CGRA tiles in an existing Innovus session.
#
# Usage inside Innovus:
#   set restore_db_file_check 0
#   source enc/cgra.enc
#   source highlight_tiles.tcl
#
# This script does not modify placement or routing. It only groups and
# highlights instances whose names carry the tile__<id>_ prefix preserved by
# synthesis/implementation.

proc qjj_get_tile_inst_ptrs {tile_id} {
    set prefix "tile__${tile_id}_"
    set escaped_prefix [string map {_ \\_} $prefix]

    set raw_ptrs [dbGet top.insts.name ${escaped_prefix}* -p]
    set dedup_ptrs [lsort -unique $raw_ptrs]

    set tile_ptrs {}
    foreach inst_ptr $dedup_ptrs {
        if {$inst_ptr ne "0x0" && $inst_ptr ne ""} {
            lappend tile_ptrs $inst_ptr
        }
    }
    return $tile_ptrs
}

proc qjj_highlight_tile {tile_id color_index} {
    set tile_ptrs [qjj_get_tile_inst_ptrs $tile_id]
    set inst_count [llength $tile_ptrs]

    if {$inst_count == 0} {
        puts "tile__${tile_id}: no instances matched"
        return
    }

    deselectAll
    dbSelectObj $tile_ptrs
    highlight -index $color_index
    puts [format "tile__%-2d: highlighted %8d instances with color %d" \
        $tile_id $inst_count $color_index]
}

proc qjj_highlight_all_tiles {} {
    set color_cycle {1 2 3 4 5 6 7 8}

    puts "Logical 4x4 tile numbering:"
    puts "12 13 14 15"
    puts " 8  9 10 11"
    puts " 4  5  6  7"
    puts " 0  1  2  3"
    puts ""

    for {set tile_id 0} {$tile_id < 16} {incr tile_id} {
        set color_index [lindex $color_cycle [expr {$tile_id % [llength $color_cycle]}]]
        qjj_highlight_tile $tile_id $color_index
    }

    deselectAll
    puts ""
    puts "Done. Use the Innovus highlight controls to toggle colors if needed."
}

qjj_highlight_all_tiles
