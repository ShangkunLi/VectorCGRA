#!/usr/bin/env bash
set -euo pipefail

export CGRA_INNOVUS_CPUS="${CGRA_INNOVUS_CPUS:-8}"

INNOVUS_BIN="${INNOVUS_BIN:-}"
if [ -z "${INNOVUS_BIN}" ]; then
  if command -v innovus >/dev/null 2>&1; then
    INNOVUS_BIN="$(command -v innovus)"
  elif [ -x /tools/cadence/INNOVUS201/bin/innovus ]; then
    INNOVUS_BIN="/tools/cadence/INNOVUS201/bin/innovus"
  else
    echo "Cannot find Innovus binary." >&2
    exit 1
  fi
fi

mkdir -p syn_handoff log summaryReport enc def
cp -f cgra_netlist.v syn_handoff/cgra.v
cp -f cgra.sdc syn_handoff/cgra.sdc

"${INNOVUS_BIN}" -64 -overwrite -log log/innovus.log -files run_invs.tcl
