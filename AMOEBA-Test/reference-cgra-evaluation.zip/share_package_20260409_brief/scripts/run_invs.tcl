# Custom Innovus flow for synthesized cgra handoff.

source lib_setup.tcl
source design_setup.tcl
source report_utils.tcl

set local_cpus 8
if {[info exists ::env(CGRA_INNOVUS_CPUS)] && $::env(CGRA_INNOVUS_CPUS) ne ""} {
    set local_cpus $::env(CGRA_INNOVUS_CPUS)
}
setMultiCpuUsage -localCpu $local_cpus

set netlist $NETLIST
set sdc $SDC_FILE
source mmmc_setup.tcl

set rptDir "summaryReport"
set encDir "enc"
set defDir "def"

foreach dir [list $rptDir $encDir $defDir] {
    if {![file exists $dir]} {
        exec mkdir -p $dir
    }
}

set init_pwr_net VDD
set init_gnd_net VSS
set init_verilog $netlist
set init_design_netlisttype "Verilog"
set init_design_settop 1
set init_top_cell $TOP_MODULE
set init_lef_file $lefs

init_design -setup {WC_VIEW} -hold {BC_VIEW}
set_power_analysis_mode -leakage_power_view WC_VIEW -dynamic_power_view WC_VIEW

set_interactive_constraint_modes {CON}
setAnalysisMode -reset
setAnalysisMode -analysisType onChipVariation -cppr both

clearGlobalNets
globalNetConnect VDD -type pgpin -pin VDD -inst * -override
globalNetConnect VSS -type pgpin -pin VSS -inst * -override
globalNetConnect VDD -type tiehi -inst * -override
globalNetConnect VSS -type tielo -inst * -override

setOptMode -powerEffort low -leakageToDynamicRatio 0.5 \
    -fixCap true -fixTran true -fixFanoutLoad true
setGenerateViaMode -auto true
generateVias
createBasicPathGroups -expanded

source ${UTIL_ROOT}/place_pin.tcl

proc place_pins_round_robin {perc} {
    array set side_pins {0 {} 1 {} 2 {} 3 {}}
    set all_pins [lsort [dbget top.terms.name]]
    set side 0

    foreach pin $all_pins {
        lappend side_pins($side) $pin
        set side [expr {($side + 1) % 4}]
    }

    for {set s 0} {$s < 4} {incr s} {
        puts "Placing [llength $side_pins($s)] pins on side $s"
        if {[llength $side_pins($s)] > 0} {
            place_pins $s $side_pins($s) $perc
        }
    }
}

setFPlanMode -snapBlockGrid LayerTrack
floorPlan -site $SITE -r 1.0 $FP_UTIL $FP_MARGIN $FP_MARGIN $FP_MARGIN $FP_MARGIN
place_pins_round_robin $PIN_SPREAD_FRACTION

if {[info exists TILE_GRID_ENABLE] && $TILE_GRID_ENABLE} {
    source tile_grid_constraints.tcl
}

echo "Physical Design Stage, Core Area (um^2), Standard Cell Area (um^2), Macro Area (um^2), Total Power (mW), Wirelength(um), WS(ns), TNS(ns), Congestion(H), Congestion(V)" > ${DESIGN}_DETAILS.rpt
set rpt_post_synth [extract_report postSynth]
echo "$rpt_post_synth" >> ${DESIGN}_DETAILS.rpt

defOut -floorplan ${defDir}/${DESIGN}_fp.def
saveNetlist -removePowerGround ${defDir}/${TOP_MODULE}.v
saveNetlist -flat -removePowerGround ${defDir}/${TOP_MODULE}_flat.v

source $PDN_CONFIG
source ${UTIL_ROOT}/pdn_flow.tcl

saveDesign ${encDir}/${DESIGN}_floorplan.enc

setPlaceMode -place_detail_legalization_inst_gap 1
setFillerMode -fitGap true
setDesignMode -topRoutingLayer $TOP_ROUTING_LAYER
setDesignMode -bottomRoutingLayer 2

place_opt_design -out_dir $rptDir -prefix place
optDesign -preCTS
saveDesign ${encDir}/${DESIGN}_placed.enc
defOut -floorplan -placement ${defDir}/${DESIGN}_placed.def

set rpt_pre_cts [extract_report preCTS]
echo "$rpt_pre_cts" >> ${DESIGN}_DETAILS.rpt

set_ccopt_property post_conditioning_enable_routing_eco 1
set_ccopt_property -cts_def_lock_clock_sinks_after_routing true
setOptMode -unfixClkInstForOpt false

create_ccopt_clock_tree_spec
ccopt_design

set_interactive_constraint_modes [all_constraint_modes -active]
set_propagated_clock [all_clocks]
set_clock_propagation propagated
optDesign -postCTS

saveDesign ${encDir}/${DESIGN}_cts.enc
set rpt_post_cts [extract_report postCTS]
echo "$rpt_post_cts" >> ${DESIGN}_DETAILS.rpt

setNanoRouteMode -drouteVerboseViolationSummary 1
setNanoRouteMode -routeWithSiDriven true
setNanoRouteMode -routeWithTimingDriven true
setNanoRouteMode -routeUseAutoVia true
setNanoRouteMode -routeWithViaInPin "1:1"
setNanoRouteMode -routeWithViaOnlyForStandardCellPin "1:1"
setNanoRouteMode -drouteOnGridOnly "via 1:1"
setNanoRouteMode -drouteAutoStop false
setNanoRouteMode -drouteExpAdvancedMarFix true
setNanoRouteMode -routeExpAdvancedTechnology true
setNanoRouteMode -grouteExpWithTimingDriven false

routeDesign
saveDesign ${encDir}/${DESIGN}_route.enc
defOut -netlist -floorplan -routing ${DESIGN}_route.def

setViaGenMode -reset
editPowerVia -top_layer M2 -bottom_layer M1 -orthogonal_only 0 -add_vias 1

verify_connectivity -error 0 -geom_connect -no_antenna
verify_drc -limit 0

set rpt_post_route [extract_report postRoute]
echo "$rpt_post_route" >> ${DESIGN}_DETAILS.rpt

optDesign -postRoute

set rpt_post_route_opt [extract_report postRouteOpt]
echo "$rpt_post_route_opt" >> ${DESIGN}_DETAILS.rpt

verify_connectivity -error 0 -geom_connect -no_antenna
verify_drc -limit 0

summaryReport -noHtml -outfile ${rptDir}/post_route.sum
defOut -netlist -floorplan -routing ${DESIGN}.def
saveDesign ${encDir}/${DESIGN}.enc

exit
