# Custom ASAP7 Innovus library setup for cgra.

set REF_ROOT "/workspace/code/phdyear0/reference/MacroPlacement"
set libdir "${REF_ROOT}/Enablements/ASAP7/lib"
set lefdir "${REF_ROOT}/Enablements/ASAP7/lef"
set qrcdir "${REF_ROOT}/Enablements/ASAP7/qrc"

set init_lib_search_path [list \
    $libdir \
    $lefdir \
]

set libworst [list \
    ${libdir}/asap7sc7p5t_AO_RVT_FF_nldm_201020.lib \
    ${libdir}/asap7sc7p5t_INVBUF_RVT_FF_nldm_201020.lib \
    ${libdir}/asap7sc7p5t_OA_RVT_FF_nldm_201020.lib \
    ${libdir}/asap7sc7p5t_SEQ_RVT_FF_nldm_201020.lib \
    ${libdir}/asap7sc7p5t_SIMPLE_RVT_FF_nldm_201020.lib \
]

set libbest $libworst

set lefs [list \
    ${lefdir}/asap7_tech_1x_201209.lef \
    ${lefdir}/asap7sc7p5t_27_R_1x_201211.lef \
]

set qrc_max "${qrcdir}/ASAP7.tch"
set qrc_min "${qrcdir}/ASAP7.tch"

setDesignMode -process 7
