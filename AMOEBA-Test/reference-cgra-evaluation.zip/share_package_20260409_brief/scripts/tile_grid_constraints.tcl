# Create logical 4x4 tile placement constraints for the flattened CGRA netlist.
#
# The flow preserves instance-name prefixes such as tile__0_, tile__1_, ...
# These prefixes let us rebuild per-tile groups even after synthesis flattening.
#
# Expected variables from design_setup.tcl:
#   TILE_GRID_ENABLE
#   TILE_GRID_ROWS
#   TILE_GRID_COLS
#   TILE_GRID_MODE      ;# "region" or "fence"
#   TILE_GRID_CHANNEL   ;# spacing between neighboring tiles, in microns
# Optional stronger-boundary controls:
#   TILE_GRID_BOUNDARY_PLACE_BLKG
#   TILE_GRID_BOUNDARY_PLACE_BLKG_WIDTH
#   TILE_GRID_BOUNDARY_ROUTE_BLKG
#   TILE_GRID_BOUNDARY_ROUTE_BLKG_WIDTH
#   TILE_GRID_BOUNDARY_ROUTE_LAYERS

proc qjj_collect_tile_instances {tile_id} {
    set prefix "tile__${tile_id}_"
    set escaped_prefix [string map {_ \\_} $prefix]
    set raw_names [dbGet top.insts.name ${escaped_prefix}*]

    set inst_names {}
    foreach inst_name [lsort -unique $raw_names] {
        if {$inst_name ne "" && $inst_name ne "0x0"} {
            lappend inst_names $inst_name
        }
    }
    return $inst_names
}

proc qjj_create_tile_box_constraint {mode group_name box} {
    lassign $box llx lly urx ury

    if {$mode eq "fence"} {
        set attempts [list \
            [list createFence $group_name $box] \
            [list createFence $group_name $llx $lly $urx $ury] \
        ]
    } else {
        set attempts [list \
            [list createRegion $group_name $box] \
            [list createRegion $group_name $llx $lly $urx $ury] \
        ]
    }

    set last_error ""
    foreach cmd $attempts {
        if {![catch {uplevel #0 $cmd} result]} {
            return
        }
        set last_error $result
    }

    error "Failed to create ${mode} for ${group_name}: ${last_error}"
}

proc qjj_delete_place_blockage_if_exists {name} {
    catch {deletePlaceBlockage -name $name}
    catch {deletePlaceBlockage $name}
}

proc qjj_delete_route_blockage_if_exists {name} {
    catch {deleteRouteBlk -name $name}
    catch {deleteRouteBlk $name}
}

proc qjj_create_tile_boundary_place_blockages {tile_id box width} {
    lassign $box llx lly urx ury
    if {$width <= 0.0} {
        return
    }

    set x1 [expr {$llx + $width}]
    set y1 [expr {$lly + $width}]
    set x2 [expr {$urx - $width}]
    set y2 [expr {$ury - $width}]

    if {$x1 >= $x2 || $y1 >= $y2} {
        puts "tile_${tile_id}: boundary placement blockage width is too large, skipping"
        return
    }

    set tile_tag [format "%02d" $tile_id]
    foreach {suffix blk_box} [list \
        l [list $llx $lly $x1  $ury] \
        r [list $x2  $lly $urx $ury] \
        b [list $x1  $lly $x2  $y1] \
        t [list $x1  $y2  $x2  $ury] \
    ] {
        set name [format "qjj_tile_box_%s_%s" $tile_tag $suffix]
        qjj_delete_place_blockage_if_exists $name
        createPlaceBlockage -type soft -box $blk_box -name $name
    }
}

proc qjj_create_global_grid_channel_blockages {rows cols core_llx core_lly core_urx core_ury tile_w tile_h channel} {
    if {$channel <= 0.0} {
        return
    }

    for {set col 0} {$col < ($cols - 1)} {incr col} {
        set x0 [expr {$core_llx + ($col + 1) * $tile_w + $col * $channel}]
        set x1 [expr {$x0 + $channel}]
        set name [format "qjj_tile_grid_v_%d" $col]
        qjj_delete_place_blockage_if_exists $name
        createPlaceBlockage -type soft -box [list $x0 $core_lly $x1 $core_ury] -name $name
    }

    for {set row 0} {$row < ($rows - 1)} {incr row} {
        set y0 [expr {$core_lly + ($row + 1) * $tile_h + $row * $channel}]
        set y1 [expr {$y0 + $channel}]
        set name [format "qjj_tile_grid_h_%d" $row]
        qjj_delete_place_blockage_if_exists $name
        createPlaceBlockage -type soft -box [list $core_llx $y0 $core_urx $y1] -name $name
    }
}

proc qjj_create_tile_boundary_route_blockages {tile_id box width layer_names} {
    lassign $box llx lly urx ury
    if {$width <= 0.0 || [llength $layer_names] == 0} {
        return
    }

    set x1 [expr {$llx + $width}]
    set y1 [expr {$lly + $width}]
    set x2 [expr {$urx - $width}]
    set y2 [expr {$ury - $width}]

    if {$x1 >= $x2 || $y1 >= $y2} {
        puts "tile_${tile_id}: boundary route blockage width is too large, skipping"
        return
    }

    set tile_tag [format "%02d" $tile_id]
    foreach {suffix blk_box} [list \
        l [list $llx $lly $x1  $ury] \
        r [list $x2  $lly $urx $ury] \
        b [list $x1  $lly $x2  $y1] \
        t [list $x1  $y2  $x2  $ury] \
    ] {
        set name [format "qjj_tile_route_%s_%s" $tile_tag $suffix]
        qjj_delete_route_blockage_if_exists $name
        createRouteBlk -box $blk_box -layer $layer_names -name $name
    }
}

proc qjj_apply_tile_grid_constraints {} {
    global TILE_GRID_ROWS TILE_GRID_COLS TILE_GRID_MODE TILE_GRID_CHANNEL
    global TILE_GRID_BOUNDARY_PLACE_BLKG TILE_GRID_BOUNDARY_PLACE_BLKG_WIDTH
    global TILE_GRID_BOUNDARY_ROUTE_BLKG TILE_GRID_BOUNDARY_ROUTE_BLKG_WIDTH
    global TILE_GRID_BOUNDARY_ROUTE_LAYERS

    set mode [string tolower $TILE_GRID_MODE]
    if {$mode ni {"region" "fence"}} {
        error "TILE_GRID_MODE must be either \"region\" or \"fence\""
    }

    set rows $TILE_GRID_ROWS
    set cols $TILE_GRID_COLS
    set channel $TILE_GRID_CHANNEL
    set add_place_blk [expr {[info exists TILE_GRID_BOUNDARY_PLACE_BLKG] && $TILE_GRID_BOUNDARY_PLACE_BLKG}]
    set place_blk_w 0.0
    if {$add_place_blk && [info exists TILE_GRID_BOUNDARY_PLACE_BLKG_WIDTH]} {
        set place_blk_w $TILE_GRID_BOUNDARY_PLACE_BLKG_WIDTH
    }

    set add_route_blk [expr {[info exists TILE_GRID_BOUNDARY_ROUTE_BLKG] && $TILE_GRID_BOUNDARY_ROUTE_BLKG}]
    set route_blk_w 0.0
    if {$add_route_blk && [info exists TILE_GRID_BOUNDARY_ROUTE_BLKG_WIDTH]} {
        set route_blk_w $TILE_GRID_BOUNDARY_ROUTE_BLKG_WIDTH
    }
    set route_blk_layers {}
    if {$add_route_blk && [info exists TILE_GRID_BOUNDARY_ROUTE_LAYERS]} {
        set route_blk_layers $TILE_GRID_BOUNDARY_ROUTE_LAYERS
    }

    set core_llx [dbGet top.fplan.coreBox_llx]
    set core_lly [dbGet top.fplan.coreBox_lly]
    set core_urx [dbGet top.fplan.coreBox_urx]
    set core_ury [dbGet top.fplan.coreBox_ury]
    set core_w [expr {$core_urx - $core_llx}]
    set core_h [expr {$core_ury - $core_lly}]

    set tile_w [expr {($core_w - ($cols - 1) * $channel) / double($cols)}]
    set tile_h [expr {($core_h - ($rows - 1) * $channel) / double($rows)}]

    if {$tile_w <= 0.0 || $tile_h <= 0.0} {
        error "Tile grid geometry is invalid. Check TILE_GRID_CHANNEL / rows / cols."
    }

    puts ""
    puts [format "Applying %s constraints for logical %dx%d tile grid" $mode $rows $cols]
    puts [format "Core box : {%.3f %.3f %.3f %.3f}" $core_llx $core_lly $core_urx $core_ury]
    puts [format "Tile box : width=%.3f height=%.3f channel=%.3f" $tile_w $tile_h $channel]
    puts [format "Boundary placement blockage : %s (width=%.3f)" $add_place_blk $place_blk_w]
    puts [format "Boundary route blockage     : %s (width=%.3f layers=%s)" $add_route_blk $route_blk_w $route_blk_layers]
    puts "Logical numbering:"
    puts "12 13 14 15"
    puts " 8  9 10 11"
    puts " 4  5  6  7"
    puts " 0  1  2  3"
    puts ""

    set rpt [open "tile_grid_regions.rpt" "w"]
    puts $rpt "tile_id,group_name,mode,inst_count,llx,lly,urx,ury"

    if {$add_place_blk} {
        qjj_create_global_grid_channel_blockages \
            $rows $cols $core_llx $core_lly $core_urx $core_ury $tile_w $tile_h $channel
    }

    for {set row 0} {$row < $rows} {incr row} {
        for {set col 0} {$col < $cols} {incr col} {
            set tile_id [expr {$row * $cols + $col}]
            set group_name [format "tile_%d" $tile_id]
            set inst_names [qjj_collect_tile_instances $tile_id]
            set inst_count [llength $inst_names]

            if {$inst_count == 0} {
                puts "tile_${tile_id}: no instances found, skipping"
                continue
            }

            set llx [expr {$core_llx + $col * ($tile_w + $channel)}]
            set lly [expr {$core_lly + $row * ($tile_h + $channel)}]
            set urx [expr {$llx + $tile_w}]
            set ury [expr {$lly + $tile_h}]
            set box [list $llx $lly $urx $ury]

            createInstGroup $group_name
            foreach inst_name $inst_names {
                addInstToInstGroup $group_name $inst_name
            }

            qjj_create_tile_box_constraint $mode $group_name $box

            if {$add_place_blk} {
                qjj_create_tile_boundary_place_blockages $tile_id $box $place_blk_w
            }
            if {$add_route_blk} {
                qjj_create_tile_boundary_route_blockages $tile_id $box $route_blk_w $route_blk_layers
            }

            puts [format "%-7s : %6d insts -> {%.3f %.3f %.3f %.3f}" \
                $group_name $inst_count $llx $lly $urx $ury]
            puts $rpt [format "%d,%s,%s,%d,%.3f,%.3f,%.3f,%.3f" \
                $tile_id $group_name $mode $inst_count $llx $lly $urx $ury]
        }
    }

    close $rpt
    puts ""
    puts "Wrote tile_grid_regions.rpt"
}

if {[info exists TILE_GRID_ENABLE] && $TILE_GRID_ENABLE} {
    qjj_apply_tile_grid_constraints
}
