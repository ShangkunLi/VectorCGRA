# Show the routed layout together with 4x4 tile highlighting.
#
# Usage inside Innovus:
#   set restore_db_file_check 0
#   restoreDesign enc/cgra.enc.dat Cgra4x4TemplateRTL
#   source show_tile_overlay.tcl
#
# This keeps routing/cut layers visible, unlike show_tile_regions.tcl's default
# region-only mode. It also disables instance highlight fill and instead draws
# 16 GUI tile boxes on top of the routed layout.

set ::qjj_tile_view_mode "overlay"
set ::qjj_tile_highlight_enable 0
set ::qjj_tile_outline_width 5
set ::qjj_tile_label_enable 1
set ::qjj_tile_label_mode "id"
set ::qjj_tile_gui_box_layer "qjj_tile_box"
set ::qjj_tile_gui_text_layer "qjj_tile_text"
source [file join [file dirname [info script]] show_tile_regions.tcl]
