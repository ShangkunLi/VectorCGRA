# Visualize the logical 4x4 CGRA tile regions in Innovus.
#
# Recommended usage inside Innovus:
#   set restore_db_file_check 0
#   restoreDesign enc/cgra_placed.enc.dat Cgra4x4TemplateRTL
#   source show_tile_regions.tcl
#
# For routed-layout overlay instead of a floorplan-only view:
#   set restore_db_file_check 0
#   restoreDesign enc/cgra.enc.dat Cgra4x4TemplateRTL
#   source show_tile_overlay.tcl
#
# The placement flow already created tile_0..tile_15 regions and instance
# groups. This script only changes the GUI view so the 4x4 structure is easier
# to see:
#   1. show floorplan/group objects in placed or routed view
#   2. optionally hide routing/cut layers for a pure 4x4 region view
#   3. highlight each logical tile with a repeatable color
#   4. print the tile numbering and region coordinates

proc qjj_abort_if_no_design {} {
    if {[catch {set top_name [dbGet top.name]}] || $top_name eq "" || $top_name eq "0x0"} {
        error "No Innovus design is loaded. Run restoreDesign first, then source this script."
    }
}

proc qjj_try_set_preference {name value} {
    catch {setPreference $name $value}
}

proc qjj_try_set_layer_visibility {layer_name is_visible} {
    catch {setLayerPreference $layer_name -isVisible $is_visible}
}

proc qjj_get_routing_layer_names {} {
    set names {}
    foreach layer_ptr [dbGet head.layers] {
        if {$layer_ptr eq "0x0" || $layer_ptr eq ""} {
            continue
        }
        if {[string tolower [dbGet $layer_ptr.type]] eq "routing"} {
            lappend names [dbGet $layer_ptr.name]
        }
    }
    return $names
}

proc qjj_get_place_blockage_names {} {
    set names {}
    foreach name [dbGet top.fPlan.pBlkgs.name] {
        if {$name ne "" && $name ne "0x0"} {
            lappend names $name
        }
    }
    return $names
}

proc qjj_clear_tile_grid_blockages {} {
    if {![info exists ::qjj_tile_grid_blk_names]} {
        return
    }

    foreach blk_name $::qjj_tile_grid_blk_names {
        catch {deleteRouteBlk -name $blk_name}
        catch {deletePlaceBlockage -name $blk_name}
        catch {deletePlaceBlockage $blk_name}
    }
    unset ::qjj_tile_grid_blk_names
}

proc qjj_set_route_layer_visibility {is_visible} {
    set layer_ptrs [dbGet head.layers]
    foreach layer_ptr $layer_ptrs {
        if {$layer_ptr eq "0x0" || $layer_ptr eq ""} {
            continue
        }

        set layer_name [dbGet $layer_ptr.name]
        set layer_type [string tolower [dbGet $layer_ptr.type]]

        if {$layer_type eq "routing" || $layer_type eq "cut"} {
            qjj_try_set_layer_visibility $layer_name $is_visible
        }
    }
}

proc qjj_enable_floorplan_view {} {
    # Make floorplan objects and group names visible even in placed/routed DBs.
    qjj_try_set_preference DisplayRelFPlan 1
    qjj_try_set_preference ShowFPObjInPlace 1
    qjj_try_set_preference ShowAllFence 1
    qjj_try_set_preference ShowGroupText 1

    # Reduce clutter so the 4x4 tile boxes stand out.
    qjj_try_set_preference ShowInstanceText 0
    qjj_try_set_preference ShowInstancePinText 0
    qjj_try_set_preference ShowIoPinText 0
    qjj_try_set_preference ShowNetText 0
    qjj_try_set_preference ShowModuleText 0
    qjj_try_set_preference ShowUtilizationText 0
    qjj_try_set_preference DisplayPinName 0
    qjj_try_set_preference AutoDetailDisplay 0
    qjj_try_set_preference DetailDisplayFactor 1000000
}

proc qjj_select_objs {obj_list} {
    if {[llength $obj_list] == 0} {
        return
    }

    # In this Innovus build, select_obj does not accept the db pointers
    # returned by dbGet top.insts... -p. Keep using dbSelectObj with the whole
    # Tcl list as one argument, which works reliably here.
    if {![catch {uplevel #0 [list dbSelectObj $obj_list]}]} {
        return
    }

    # Last-resort fallback: convert object pointers back to instance names and
    # try name-based selection.
    set inst_names {}
    foreach obj_ptr $obj_list {
        set inst_name [dbGet $obj_ptr.name]
        if {$inst_name ne "" && $inst_name ne "0x0"} {
            lappend inst_names $inst_name
        }
    }

    if {[llength $inst_names] > 0} {
        uplevel #0 [concat selectInst $inst_names]
        return
    }

    error "Failed to select tile objects."
}

proc qjj_get_tile_inst_ptrs {tile_id} {
    set prefix "tile__${tile_id}_"
    set escaped_prefix [string map {_ \\_} $prefix]

    set raw_ptrs [dbGet top.insts.name ${escaped_prefix}* -p]
    set dedup_ptrs [lsort -unique $raw_ptrs]

    set tile_ptrs {}
    foreach inst_ptr $dedup_ptrs {
        if {$inst_ptr ne "0x0" && $inst_ptr ne ""} {
            lappend tile_ptrs $inst_ptr
        }
    }
    return $tile_ptrs
}

proc qjj_highlight_tile {tile_id color_index} {
    set tile_ptrs [qjj_get_tile_inst_ptrs $tile_id]
    set inst_count [llength $tile_ptrs]

    if {$inst_count == 0} {
        puts [format "tile_%-2d : no instances matched" $tile_id]
        return
    }

    deselectAll
    qjj_select_objs $tile_ptrs
    highlight -index $color_index
    puts [format "tile_%-2d : highlighted %8d instances with color %d" \
        $tile_id $inst_count $color_index]
}

proc qjj_print_tile_legend {} {
    puts ""
    puts "Logical 4x4 tile numbering:"
    puts "12 13 14 15"
    puts " 8  9 10 11"
    puts " 4  5  6  7"
    puts " 0  1  2  3"
    puts ""
}

proc qjj_print_tile_boxes {{rpt_file "tile_grid_regions.rpt"}} {
    if {![file exists $rpt_file]} {
        puts "Did not find $rpt_file. Region boxes are expected to already exist in the restored DB."
        return
    }

    puts "Tile region boxes from $rpt_file:"
    set fp [open $rpt_file r]
    set is_header 1
    while {[gets $fp line] >= 0} {
        if {$is_header} {
            set is_header 0
            continue
        }
        if {[string trim $line] eq ""} {
            continue
        }

        set fields [split $line ,]
        if {[llength $fields] != 8} {
            continue
        }

        lassign $fields tile_id group_name mode inst_count llx lly urx ury
        puts [format "  %-7s %6s insts  box={%8.3f %8.3f %8.3f %8.3f}" \
            $group_name $inst_count $llx $lly $urx $ury]
    }
    close $fp
    puts ""
}

proc qjj_load_tile_boxes {{rpt_file "tile_grid_regions.rpt"}} {
    set boxes [dict create]

    if {![file exists $rpt_file]} {
        return $boxes
    }

    set fp [open $rpt_file r]
    set is_header 1
    while {[gets $fp line] >= 0} {
        if {$is_header} {
            set is_header 0
            continue
        }
        if {[string trim $line] eq ""} {
            continue
        }

        set fields [split $line ,]
        if {[llength $fields] != 8} {
            continue
        }

        lassign $fields tile_id group_name mode inst_count llx lly urx ury
        dict set boxes $tile_id [list $llx $lly $urx $ury]
    }
    close $fp

    return $boxes
}

proc qjj_create_route_blk {name box layer_names} {
    if {[llength $layer_names] == 0} {
        return
    }
    catch {deleteRouteBlk -name $name}
    createRouteBlk -box $box -layer $layer_names -name $name
}

proc qjj_create_place_blk {name box} {
    set existing_names [qjj_get_place_blockage_names]
    if {[lsearch -exact $existing_names $name] >= 0} {
        return
    }
    createPlaceBlockage -type soft -box $box -name $name
}

proc qjj_draw_tile_box_outlines {{rpt_file "tile_grid_regions.rpt"}} {
    set boxes [qjj_load_tile_boxes $rpt_file]
    if {[dict size $boxes] < 16} {
        puts "Did not find enough tile boxes to draw 4x4 tile boxes."
        return
    }

    qjj_clear_tile_grid_blockages

    if {![info exists ::qjj_tile_gui_box_layer]} {
        set ::qjj_tile_gui_box_layer "qjj_tile_box"
    }
    if {![info exists ::qjj_tile_gui_text_layer]} {
        set ::qjj_tile_gui_text_layer "qjj_tile_text"
    }
    if {![info exists ::qjj_tile_outline_width]} {
        set ::qjj_tile_outline_width 5
    }
    if {![info exists ::qjj_tile_label_enable]} {
        set ::qjj_tile_label_enable 1
    }
    if {![info exists ::qjj_tile_label_mode]} {
        set ::qjj_tile_label_mode "id"
    }

    set top_name [dbGet top.name]
    set box_layer $::qjj_tile_gui_box_layer
    set text_layer $::qjj_tile_gui_text_layer
    set outline_w $::qjj_tile_outline_width

    if {[info exists ::qjj_tile_gui_annotations_active] \
        && $::qjj_tile_gui_annotations_active \
        && [info exists ::qjj_tile_gui_annotations_top] \
        && $::qjj_tile_gui_annotations_top eq $top_name \
        && !([info exists ::qjj_tile_force_redraw_gui] && $::qjj_tile_force_redraw_gui)} {
        puts "GUI tile box annotations are already drawn in this Innovus session."
        puts "If you want to redraw them, run: delete_gui_object -shape; delete_gui_object -text"
        puts "Then set ::qjj_tile_force_redraw_gui 1 and source the script again."
        return
    }

    if {[info exists ::qjj_tile_force_redraw_gui] && $::qjj_tile_force_redraw_gui} {
        catch {delete_gui_object -shape}
        catch {delete_gui_object -text}
        set ::qjj_tile_force_redraw_gui 0
    }

    for {set tile_id 0} {$tile_id < 16} {incr tile_id} {
        if {![dict exists $boxes $tile_id]} {
            continue
        }

        lassign [dict get $boxes $tile_id] llx lly urx ury

        catch {
            add_gui_shape \
                -layer $box_layer \
                -width $outline_w \
                -rect [list $llx $lly $urx $ury]
        }

        if {$::qjj_tile_label_enable} {
            switch -- [string tolower $::qjj_tile_label_mode] {
                tile {
                    set label_text [format "tile_%d" $tile_id]
                }
                default {
                    set label_text $tile_id
                }
            }
            catch {
                add_gui_text \
                    -layer $text_layer \
                    -box [list $llx $lly $urx $ury] \
                    -no_bbox \
                    -label $label_text
            }
        }
    }

    qjj_try_set_layer_visibility $box_layer 1
    qjj_try_set_layer_visibility $text_layer 1
    set ::qjj_tile_gui_annotations_active 1
    set ::qjj_tile_gui_annotations_top $top_name
}

proc qjj_highlight_all_tiles {} {
    set color_cycle {1 2 3 4 5 6 7 8}
    for {set tile_id 0} {$tile_id < 16} {incr tile_id} {
        set color_index [lindex $color_cycle [expr {$tile_id % [llength $color_cycle]}]]
        qjj_highlight_tile $tile_id $color_index
    }
    deselectAll
}

proc qjj_show_tile_regions {{keep_routes 0}} {
    qjj_abort_if_no_design
    qjj_enable_floorplan_view
    qjj_clear_tile_grid_blockages

    if {$keep_routes} {
        qjj_set_route_layer_visibility 1
    } else {
        qjj_set_route_layer_visibility 0
    }

    qjj_print_tile_legend
    qjj_print_tile_boxes

    if {![info exists ::qjj_tile_highlight_enable]} {
        set ::qjj_tile_highlight_enable 1
    }
    if {$::qjj_tile_highlight_enable} {
        qjj_highlight_all_tiles
    } else {
        catch {deselectAll}
        if {$keep_routes} {
            qjj_draw_tile_box_outlines
        }
    }

    catch {fit}

    if {$keep_routes} {
        if {$::qjj_tile_highlight_enable} {
            puts "Tile-overlay view is ready."
            puts "You are seeing routed layout plus 4x4 tile highlighting."
        } else {
            puts "Tile-box overlay view is ready."
            puts "You are seeing routed layout plus 16 GUI tile boxes and labels."
            puts "If they are hidden, enable the custom GUI layers qjj_tile_box and qjj_tile_text."
        }
    } else {
        puts "Tile-region view is ready."
        puts "If you still see routed metal, re-source this script after restoreDesign."
    }
    puts "If labels are too dense, zoom in one notch and keep ShowGroupText enabled."
}

if {![info exists ::qjj_tile_view_mode]} {
    set ::qjj_tile_view_mode "region"
}
if {![info exists ::qjj_tile_highlight_enable]} {
    set ::qjj_tile_highlight_enable 1
}

switch -- [string tolower $::qjj_tile_view_mode] {
    overlay {
        qjj_show_tile_regions 1
    }
    default {
        qjj_show_tile_regions 0
    }
}
