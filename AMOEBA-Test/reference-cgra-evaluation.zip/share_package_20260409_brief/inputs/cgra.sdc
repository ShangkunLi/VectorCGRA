###################################################################

# Created by write_sdc on Wed Apr  1 16:21:47 2026

###################################################################
set sdc_version 2.0

set_units -time ps -resistance kOhm -capacitance fF -voltage V -current mA
create_clock [get_ports clk_0_]  -name sys_clk  -period 1000  -waveform {0 500}
set_false_path   -from [get_ports reset_0_]
